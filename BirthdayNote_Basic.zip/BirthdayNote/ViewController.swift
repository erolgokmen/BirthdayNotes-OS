//
//  ViewController.swift
//  BirthdayNote
//
//  Created by Erol Gökmen on 28.01.2019.
//  Copyright © 2019 Erol Gökmen. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var textfieldName: UITextField!
    @IBOutlet weak var textFieldBirthday: UITextField!
    @IBOutlet weak var labelName: UILabel!
    @IBOutlet weak var labelBirthday: UILabel!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        let storedName=UserDefaults.standard.object(forKey: "Name")
        let storedBirthday=UserDefaults.standard.object(forKey: "Birthday")
        
        
        if let newName=storedName as?String{
            labelName.text="Name: \(newName)"
        }
        
        if let newBirthday=storedBirthday as?String{
            labelBirthday.text="Birthday: \(newBirthday)"
        }
        
    }

    @IBAction func SaveClick(_ sender: Any) {
        
        UserDefaults.standard.set(textfieldName.text!, forKey: "Name")
        UserDefaults.standard.set(textFieldBirthday.text!, forKey: "Birthday")
        UserDefaults.standard.synchronize()
       
        
        
        labelName.text="Name:\(textfieldName.text!)"
        labelBirthday.text="Birthday:\(textFieldBirthday.text!)"
        
    }
    
    @IBAction func DeleteClick(_ sender: Any) {
        let storedName=UserDefaults.standard.object(forKey: "Name")
        let storedBirthday=UserDefaults.standard.object(forKey: "Birthday")
        
        
        if (storedName as?String) != nil{
            UserDefaults.standard.removeObject(forKey: "Name")
           UserDefaults.standard.synchronize()
            labelName.text = "Name: "
        }
        
        if (storedBirthday as?String) != nil{
            UserDefaults.standard.removeObject(forKey: "Birthday")
            UserDefaults.standard.synchronize()
            labelBirthday.text = "Birthday: "
        }
        
    }
}

